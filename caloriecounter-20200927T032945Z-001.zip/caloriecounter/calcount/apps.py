from django.apps import AppConfig


class CalcountConfig(AppConfig):
    name = 'calcount'
