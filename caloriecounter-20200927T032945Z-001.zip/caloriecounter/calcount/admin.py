from django.contrib import admin
from calcount.models import myuser, Mycal
# Register your models here.
admin.site.register(myuser)
admin.site.register(Mycal)