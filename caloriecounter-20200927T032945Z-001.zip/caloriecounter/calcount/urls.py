from django.urls import path
from calcount import views
from django.contrib.auth import views as auth_views
urlpatterns=[
	path('hi',views.msg,name='hi'),
	path('home/',views.home,name='home'),
	path('signUpb/',views.signUpb,name='signUpb'),
	path('login/',auth_views.LoginView.as_view(template_name="calcount/login.html"),name='login'),
	path('main/',views.main,name='main'),
	path('signOut/', auth_views.LogoutView.as_view(template_name='calcount/home.html'), name='signOut'),
	# path('ite/',views.ite,name='ite'),
	#path('add/',views.add,name='add'),
	path('cosu/',views.cosu,name='cosu'),
	path('calb/',views.calb,name='calb'),
	path('bmr/', views.bmr, name='bmr'),
	path('udetail/', views.udetail, name='udetail'),
	path('update/',views.update,name='update'),
	path('calform/',views.adform,name='adform'),
	path('drop/',views.drop,name='drop'),
	#path('breakf/',views.index,name='breakf'),
	#path('signout',auth_views.LogoutView.as_view(template_name="calcount/signout.html"),name='signout'),
]