from django.contrib.auth.models import User
from django.db import models

#from dictionaryfield import DictionaryField
class myuser(User):
	genders=[("m","male"),("f","female")]
	age=models.IntegerField(null=True)
	gender=models.CharField(null=True,max_length=1,choices=genders)
	height=models.FloatField(null=True)
	weight=models.FloatField(null=True)
	# date = models.DateField(auto_now=True)

class Mycal(models.Model):
	brkf=models.CharField(max_length=10)
	brkfd=models.DateField(auto_now=True)
	lunch=models.CharField(max_length=10)
	lunchd=models.DateField(auto_now=True)
	dinner=models.CharField(max_length=10)
	dinnerd=models.DateField(auto_now=True)
	usd=models.ForeignKey(User, on_delete=models.CASCADE)
