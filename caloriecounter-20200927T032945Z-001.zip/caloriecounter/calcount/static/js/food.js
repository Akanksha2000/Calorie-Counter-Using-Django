// There's a Table and a Plate
// User's choose food from the table to add to their plate
// Each food item can be added multiple times
// Each food item has a calorie value
// The app will track a running total of calories on the user's plate

// Components ---------------
// Table
//  - Food Item List 
//    - Food Items
//      Show calorie count and Add to Plate button
// Plate
//  - Food Item List
//    - Food Items
//      Show quantity and calorie count
//  - Show Total Calories

function random5(){
  return Math.floor(Math.random() * 5) + 1;
}

var servedList = {
  Cheesecake: random5(),
  Apple: random5(),
  Candy: random5(),
  Bread: random5(),
  Carrot: random5()
}

var plateContents = {
  // foodName: quantity
};

var stats = {
  totalCalories: 0,
  totalItems: 0
};


// Randomize the calorie values
for(var i = 0; i < servedList.length; i++){
  servedList[i][1] = random5();
}


//Served Components
var ServedFoodItem = React.createClass({
  handleAddClicked: function(){
    // trigger an event in servedFoodItemList that will update state
    this.props.onItemAdded(this.props.name);
  },
  render: function(){
    return (
      <li className="servedFoodItem">
        <div>{this.props.name}<div>
        <div><em>Calories: {this.props.calorieValue}</em></div>
        <button onClick={this.handleAddClicked}>Add</button>
      </li>
    );
  }
});

var ServedFoodItemList = React.createClass({
  handleItemAdded: function(foodName){
    // trigger event in Dinner Table to update state
    this.props.onItemAdded(foodName);
  },
  render: function(){
    var foodNodes = [];
    var served = this.props.servedData;
    for(var foodName in served){
      foodNodes.push(
        <ServedFoodItem 
          calorieValue={served[foodName]} 
          name={foodName} 
          onItemAdded={this.handleItemAdded} 
        />
      );
    }
    return (
      <ul className="servedFoodItemList">
        <h2>Available Food Items<h2>        
        {foodNodes}
      </ul>
    );
  }
});

// Plate Components
var PlatedFoodItem = React.createClass({
  handleRemoveClicked: function(){
    this.props.onItemRemoved(this.props.name);
  },
  render: function(){
    return (
      <li className="platedFoodItem">
        <div>{this.props.name}<div>
        <div><em>Calories: {this.props.calorieValue}</em></div>
        <div><strong>Quantity: {this.props.quantity}</strong></div>
        <button onClick={this.handleRemoveClicked}>Remove</button>
      </li>
    );
  }
});

var PlatedFoodItemList = React.createClass({
  handleItemRemoved: function(foodName){
    this.props.onItemRemoved(foodName);
  },
  render: function(){
    var foodNodes = [];
    var plate = this.props.platedData;
    var served = this.props.servedData;
    for(var foodName in served){
      if(plate.hasOwnProperty(foodName)){
        foodNodes.push(
          <PlatedFoodItem 
            calorieValue={served[foodName]} 
            quantity={plate[foodName]} 
            name={foodName}
            onItemRemoved={this.handleItemRemoved}
          />
        );
      }
    }
    return (
      <ul className="platedFoodItemList">
        <h2>My Plate<h2>
        <div className="stats">
          <h3>Total Calories: {this.props.stats.totalCalories}<h3>
          <h3>Total Items: {this.props.stats.totalItems}<h3>
        <div>
        {foodNodes}
      <ul>
    );
  }
});


// DinnerTable Component
var DinnerTable = React.createClass({
  handleItemAdded: function(foodName){
    // update plateContents to mock a server update
    if(plateContents.hasOwnProperty(foodName)){
      plateContents[foodName] += 1;
    }else{
      plateContents[foodName] = 1;
    }
    stats.totalCalories += this.props.servedData[foodName];
    stats.totalItems++;
    this.setState({platedData: plateContents, stats: stats});
  },
  handleItemRemoved: function(foodName){
    plateContents[foodName] -= 1;
    if(plateContents[foodName] <= 0) {
      delete plateContents[foodName];
    }
    stats.totalCalories -= this.props.servedData[foodName];
    stats.totalItems--;
    this.setState({platedData: plateContents, stats: stats});
  },
  render: function(){
    return (
      <div className="dinnerTable">
        <h1>Dinner Table<h1>
        <ServedFoodItemList 
          servedData={this.props.servedData} 
          onItemAdded={this.handleItemAdded}  
        />
        <PlatedFoodItemList 
          servedData= {this.props.servedData} 
          platedData={this.props.platedData} 
          stats={this.props.stats}
          onItemRemoved={this.handleItemRemoved}
        />
      <div>
    );
  }
});

ReactDOM.render(
  <DinnerTable servedData={servedList} platedData={plateContents} stats={stats}/>,
  document.getElementById('content')
);