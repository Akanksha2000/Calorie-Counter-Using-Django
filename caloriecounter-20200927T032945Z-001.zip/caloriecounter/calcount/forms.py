from django.forms import ModelForm
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from calcount.models import myuser, Mycal
from django import forms
#from collections import OrderedDict
#from django.db import models
#from dictionaryfield import DictionaryFormField

class UserSignupForm(UserCreationForm):
	class Meta:
		model = myuser
		fields =  ['username','first_name','last_name']
		widgets={
			"username":forms.TextInput(attrs={"class":"form-control","placeholder":"Enter Username"}),
			"password":forms.PasswordInput(render_value=True,attrs={"class":"form-control","placeholder":"Enter password"}),
			"first_name":forms.TextInput(attrs={"class":"form-control","placeholder":"first_name"}),
			"last_name":forms.TextInput(attrs={"class":"form-control","placeholder":"last_name"}),
		}
class Calform(forms.ModelForm):
	class Meta:
		model=Mycal
		fields=['brkf','lunch','dinner']


#class MyForm(models.Model):
	#sample_field = DictionaryFormField("Sample field label",fields=OrderedDict([('volume', fields.CharField(label='Volume', required=False)),('issue', fields.CharField(label='Issue', required=False))]))