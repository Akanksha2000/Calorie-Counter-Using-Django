from django.shortcuts import render,redirect
from django.http import HttpResponse
from calcount.forms import UserSignupForm,Calform
from calcount.models import myuser, User
from django.contrib.auth.decorators import login_required
# Create your views here.
def msg(request):
	return HttpResponse('hi i am here')

def adform(request):
	urn=User.objects.get(id=request.user.id)
	if request.method=='POST':
		adf=Calform(request.POST)
		if adf.is_valid():
			b=adf.save(commit=False)
			b.usd_id=urn.id
			# print(b.usd_id,urn.id)
			b.save()
			return redirect('main')
	adf=Calform()
	return render(request,'calcount/calform.html',{'k':adf})
def drop(request):
	return render(request,'calcount/drop.html')

def home(request):
	return render(request,'calcount/home.html')

def signUpb(request):
	if request.method == 'POST':
		form = UserSignupForm(request.POST)
		gender = request.POST['gender']
		age = request.POST['age']
		height = request.POST['height']
		weight = request.POST['weight']
		if form.is_valid():
			obj = form.save(commit=False)
			obj.gender = gender
			obj.age = age
			obj.height = height
			obj.weight = weight
			print(obj)
			obj.save()
			return redirect('login')
	form = UserSignupForm()
	return render(request,'calcount/signUpb.html',{'form':form})
@login_required	
def main(request):
	return render(request,'calcount/main.html')

# def ite(request):
# 	if request.method == 'POST':
# 		gender = request.POST['gender']
# 		age = request.POST['age']
# 		height = request.POST['height']
# 		weight = request.POST['weight']
# 		id = request.user.id
# 		print(id)
# 	return render(request,'calcount/ite.html')
@login_required	
def cosu(request):
	if request.method =="POST":
		calSum = 0
		calSum += sum(map(int,request.POST.getlist('BreakFast')))
		calSum += sum(map(int,request.POST.getlist('lunch')))
		calSum += sum(map(int,request.POST.getlist('dinner')))
		return render(request, 'calcount/cosu.html', {'calSum':calSum})
	return render(request,'calcount/cosu.html',{'calSum':False})

#def add(request):
	#return render(request,'calcount/add.html')

@login_required	
def calb(request):
	if request.method == 'POST':
		distance=int(request.POST["distance"])
		time_h=int(request.POST["time_h"])
		time_m=int(request.POST["time_m"])
		time_s=int(request.POST["time_s"])
		weight=int(request.POST["weight"])
		distance_unit=request.POST["distance_unit"]
		weight_unit=request.POST["weight_unit"]
		if(distance_unit == 'mile'):
			distance = 1.60934 * distance
		if(weight_unit == 'lb'):
			weight=0.453*weight
		calories=distance*weight*1.036
		time=(time_h*3600)+(time_m*60)+(time_s)
		cph=(distance*weight*1.036)*3600/time
		return render(request,'calcount/calb.html',{'calories':calories,'cph':cph})
	return render(request,'calcount/calb.html',{'calories':False,'cph':False})

@login_required	
def bmr(request):
	user = myuser.objects.get(id=request.user.id)
	if user.gender == "M":
		bmr = 66.5+(13.75*user.weight)+(5.003*user.height)-(6.755*user.age)
	else :
		bmr = 665+(9.563*user.weight)+(1.850*user.height)-(4.676*user.age)
	return render(request, 'calcount/bmr.html', {'bmr':bmr}) 

@login_required	
def udetail(request):
	usr=myuser.objects.get(id=request.user.id)
	return render(request,'calcount/udetail.html',{'usr':usr})

@login_required	
def update(request):
	# instance = myuser.objects.get(id=request.user.id)
	if request.method == "POST":
		upuser=UserSignupForm(request.POST,instance=instance)
		if upuser.is_valid():
			upuserobj=upuser.save(commit=False)
			upuserobj.age=request.POST['age']
			upuserobj.gender=request.POST['gender']
			upuserobj.height=request.POST['height']
			upuserobj.weight=request.POST['weight']
			upuserobj.save()
			return redirect('udetail')
	usr=UserSignupForm(instance=instance)
	return render(request,'calcount/update.html',{'usr':usr})